$('.product-caro').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    rtl:true,
    navText:["" , ""],
    navClass:['owl-prev','owl-next'],
    dots:false,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:2
        },
        1000:{
            items:3
        },
        1200:{
            items:4
        }
    }
});

$(document).ready(function(){

                //navbar active click

 $(".navbar-nav li ,.contain ul li").click(function(){
   $(this).addClass("active").siblings().removeClass("active");
  });
    
            // choose product

    $(".bra3e").click(function(){
        $(".sam2").parent().css("display","none").removeClass("animated").removeClass("zoomIn").removeClass("slideInUp");
        $(".pra2").parent().css("display","block").addClass("animated").addClass("zoomIn").removeClass("slideInUp");
    });
    
    $('.samola').click(function(){
        $(".pra2").parent().css("display","none").removeClass("animated").removeClass("zoomIn").removeClass("slideInUp");
        $(".sam2").parent().css("display","block").addClass("animated").addClass("zoomIn").removeClass("slideInUp");
    });
    
    $('.allpro').click(function(){
        $('.sam2 ,.pra2').parent().css("display","block").removeClass("zoomIn").addClass("animated").addClass("slideInUp");
    });
               

});

            //عملاؤنا

$('.pepole').owlCarousel({
    loop:true,
    margin:10,
    nav:false,
    dots:false,
    rtl:true,
    autoplay:true,
    responsive:{
        0:{
            items:2
        },
        600:{
            items:4
        },
        1000:{
            items:7
        }
    }
});

                    //scroll top

$('.button-up button').click (function(){
      $('html,body').animate({
          scrollTop:$(".up-nav").offset().top},1000);
   });

$('.add1').click (function(){
    var inadd = "<input>";
    $('.new-num').append(inadd);
        });

$('.slide1').owlCarousel({
    loop:true,
    margin:10,
    nav:false,
    rtl:true,
    dots:true,
    autoplay:true,
    responsive:{
        0:{
            items:1
        }
    }
});

//fixed button
      $(window).scroll(function() {
       		var scrollVal = $(this).scrollTop();
        	if ( scrollVal > 250) {
            	
            	$('.button-up button').css({'display':'block'});
        	}
              else{
                  
            	$('.button-up button').css({'display':'none'});
              }
        	
    	});


